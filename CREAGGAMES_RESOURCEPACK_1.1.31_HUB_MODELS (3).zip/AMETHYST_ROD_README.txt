CREAGGAMES Amethyst-Angel
Die Angel ist bereits in dieses Resourcepack integriert.
Item Model: creaggenerator:amethyst_rod
Die Plugin-Source 1.1.18 setzt dieses Item Model automatisch.
