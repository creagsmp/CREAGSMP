1.1.20: Angeltexturen neu als klassische Fishing-Rod-Silhouette. Farben je Levelbereich: Lila, Weiß, Türkis und Pink.
