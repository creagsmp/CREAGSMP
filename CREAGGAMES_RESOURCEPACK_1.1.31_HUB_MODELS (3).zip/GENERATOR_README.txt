CREAGGAMES Generator Resource Pack

Namespace: creaggenerator
Custom assets included:
- generator money drops ($1 coin, $10/$50 bills, $100/$1000 bundles, $10k bag, $15k card)
- Mystical + Event crates
- Common/Rare/Super Rare/Mystery/Legendary placeable crates
- Rainbow Fish
- Farmer's Lost Nugget / Farmer's Secret
- Sell Wand
- XXL Generator mode block texture/model

This ZIP is intended to be MERGED into the main CREAGGAMES server resource pack so the server only needs one required pack.
