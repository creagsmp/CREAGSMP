1.1.22: redesigned Amethyst Farmer pickaxe textures + Pink Amethyst Water bucket texture.
Placed custom water uses real Minecraft water physics; per-source fluid tint is not supported by vanilla clients, so the custom identity is tracked server-side and by the custom bucket.
