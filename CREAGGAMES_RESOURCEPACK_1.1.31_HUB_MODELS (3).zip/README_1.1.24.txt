
1.1.24: Neon pink water rendering is handled by the plugin display overlay; pack assets remain compatible.
